# Treesp
This module helps you to perform operations on trees. The functions this module holds are 
- Insert
- maxDepth
- Indorder
- Preorder
- Postorder
- Levelorder
- Lowest common ancestor

## Installation
``` pip install treesp```

## How to use it
You can refer to __main__.py in the repository to see some examples.

## License
© 2021 Sidharth Parekh

This repository is licensed under the MIT license. See LICENSE for details.
